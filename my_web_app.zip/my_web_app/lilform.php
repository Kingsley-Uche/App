<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	 <link rel="stylesheet" href="css/bootstrap.css">
     <link rel="stylesheet" href="mystyle/css.css">
</head>
<body>
	
</body>
</html>