<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>testing</title>
	<link rel="stylesheet" href="">
</head>
<body>
	<form action="profile" method="post" accept-charset="utf-8">
	
	
	</form>
	
</body>
</html>