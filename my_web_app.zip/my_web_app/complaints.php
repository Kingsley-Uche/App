<?php

require 'logz_pro.php';
$obj= new receipt;
$obj->complaints();




?>