

<div class="row m-1">
                    <div class="col-md-12 footer">&copy;KammaSoft <?php echo date("d-m-Y");    ?>
                        
                    </div>
                    
                </div>
                


            </div>
    </div>


            <script src="js/jquery.js" type="text/javascript" ></script>
                    <script src="js/popper.min.js" type="text/javascript"></script>
                    <script src="js/bootstrap.min.js" type="text/javascript" charset="utf-8" ></script>
                    <script src="mystyle/js.js" type="text/javascript" charset="utf-8" ></script>
        
        
       
    </body>
</html>