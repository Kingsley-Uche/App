<?php
require 'logz_pro.php';

$update= new receipt;
$content=[];
$content=$update->trend_jobs();
print_r($content);




?>