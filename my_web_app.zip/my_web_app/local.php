<?php
include ('logz_pro.php');

$obj = new receipt;



$obj->lgvt($_POST['state']);




?>